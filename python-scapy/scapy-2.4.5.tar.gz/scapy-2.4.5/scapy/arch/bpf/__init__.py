# Guillaume Valadon <guillaume@valadon.net>

"""
Scapy BSD native support
"""
