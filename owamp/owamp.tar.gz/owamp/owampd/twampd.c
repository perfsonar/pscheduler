/*! \file twampd.c */
/*
 *      $Id$
 */
/************************************************************************
 *                                                                      *
 *                             Copyright (C) 2014                       *
 *                            Brocade Communications                    *
 *                          Apache License Version 2.0                  *
 *                                                                      *
 ************************************************************************/
#define TWAMP
#include "owampd.c"
