
Basic Encoding Rules
--------------------

.. autofunction:: pyasn1.codec.ber.encoder.encode(value, defMode=True, maxChunkSize=0)

.. autofunction:: pyasn1.codec.ber.decoder.decode(substrate, asn1Spec=None)
