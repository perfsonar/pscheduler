=====================================================
 ``amqp.utils``
=====================================================

.. contents::
    :local:
.. currentmodule:: amqp.utils

.. automodule:: amqp.utils
    :members:
    :undoc-members:
