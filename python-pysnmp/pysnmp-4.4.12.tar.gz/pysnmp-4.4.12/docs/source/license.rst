
License
=======

.. include:: ../../LICENSE.rst
