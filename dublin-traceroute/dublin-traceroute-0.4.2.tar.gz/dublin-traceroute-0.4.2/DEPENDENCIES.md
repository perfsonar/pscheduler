cmake
a recent enough C++11 compiler (gcc >= 4.6 or clang >= 3.3)
libtins >= 3.4
