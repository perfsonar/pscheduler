#!/bin/sh

brew update
brew install libtins
brew uninstall json-c
brew install jsoncpp
