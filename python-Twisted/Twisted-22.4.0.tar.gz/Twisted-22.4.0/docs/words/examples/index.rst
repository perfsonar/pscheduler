
:LastChangedDate: $LastChangedDate$
:LastChangedRevision: $LastChangedRevision$
:LastChangedBy: $LastChangedBy$

Examples
========

- :download:`ircLogBot.py` - connects to an IRC server and logs all messages
- :download:`minchat.py` - log bot using twisted.im
- :download:`pb_client.py`
- :download:`xmpp_client.py`
- :download:`cursesclient.py` - trivial curses-based IRC client
