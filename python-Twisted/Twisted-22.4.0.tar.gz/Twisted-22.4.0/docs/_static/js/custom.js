// Configure the Gitter sidecar chat button.
// https://sidecar.gitter.im/
window.gitter = {'chat': {'options': {
    'room': 'twisted/twisted'
  }}}
