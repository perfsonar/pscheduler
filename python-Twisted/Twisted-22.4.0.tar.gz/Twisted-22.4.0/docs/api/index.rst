API Reference
=============

This file will be overwritten by the pydoctor build triggered at the end
of the Sphinx build.

It's a hack to be able to reference the API index page from inside Sphinx
and have it as part of the TOC.
