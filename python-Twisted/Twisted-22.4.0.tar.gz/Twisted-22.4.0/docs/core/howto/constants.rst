Symbolic Constants
==================

.. note::

   ``twisted.python.constants`` has been deprecated in Twisted, and the same code has been spun out into `Constantly <http://constantly.readthedocs.org/en/latest/>`_\.
   The API is identical, just install it from PyPI and replace ``import twisted.python.constants`` with ``import constantly`` in your code.
