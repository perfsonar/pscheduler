
:LastChangedDate: $LastChangedDate$
:LastChangedRevision: $LastChangedRevision$
:LastChangedBy: $LastChangedBy$

Examples
========

DNS (Twisted Names)
-------------------

- :download:`testdns.py` - Prints the results of an Address record lookup, Mail-Exchanger record lookup, and Nameserver record lookup for the given domain name.
- :download:`dns-service.py` - Searches for SRV records in DNS.
- :download:`gethostbyname.py` - Returns the IP address for a given hostname.
