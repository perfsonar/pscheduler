import unittest


class TestCLI(unittest.TestCase):
    def test_cli_import(self):
        from wpa_supplicant import cli
