#I2 Utility library. 

Currently contains:
* error logging
* command-line parsing
* threading

The error logging and command-line parsing are taken from a utility library
that is distributed with the "volsh" code from UCAR.

http://www.scd.ucar.edu/vets/vg/Software/volsh

We have locally added:
* random number support
* hash table support

