
.. _constrain.ValueRangeConstraint:

.. |Constraint| replace:: ValueRangeConstraint

Value range constraint
----------------------

.. autoclass:: pyasn1.type.constraint.ValueRangeConstraint(start, end)
   :members:
