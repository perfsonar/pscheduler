==============
Extra Wrappers
==============

.. warning::
    .. deprecated:: 0.15
        All classes in this module have been moved or deprecated and
        will be removed in version 1.0. Check the docs for the status
        of each class.

.. automodule:: werkzeug.contrib.wrappers

.. autoclass:: JSONRequestMixin

.. autoclass:: ProtobufRequestMixin
   :members:

.. autoclass:: RoutingArgsRequestMixin
   :members:

.. autoclass:: ReverseSlashBehaviorRequestMixin
   :members:

.. autoclass:: DynamicCharsetRequestMixin
   :members:

.. autoclass:: DynamicCharsetResponseMixin
   :members:
