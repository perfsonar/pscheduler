========
API Docs
========

.. automodule:: automat

.. autoclass:: automat.MethodicalMachine
   :members: input, output, state


.. automethod:: automat._methodical.MethodicalState.upon
